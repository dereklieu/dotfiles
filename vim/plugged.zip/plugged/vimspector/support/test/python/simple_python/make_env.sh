#!/usr/bin/env bash

cat <<"EOF"
{
  "Something": "Value1",
  "SomethingElse": "Value2"
}
EOF

