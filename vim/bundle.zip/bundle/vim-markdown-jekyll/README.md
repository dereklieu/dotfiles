# vim-markdown-jekyll

## About

This is a very simple little syntax tweak to the built-in markdown syntax
adding support for the YAML front matter (as comments) and Liquid style tags
and filters. Nothing fancy but it works.

## Installing

Use Pathogen and put this folder in your bundles directory. If you don't want
to do that, put the markdown.vim file in your `~/.vim/after/syntax` directory.

## Credits

YAML front matter syntax match pattern:
* http://www.codeography.com/2010/02/20/making-vim-play-nice-with-jekylls-yaml-front-matter.html
