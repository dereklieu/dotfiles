print 'hello' 'world'
