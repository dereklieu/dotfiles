let buffer = Buffer.alloc(1024 * 1024 * 1024 - 1);
console.log(buffer.length);