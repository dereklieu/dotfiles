eval('let x = 1');

let y = 2;