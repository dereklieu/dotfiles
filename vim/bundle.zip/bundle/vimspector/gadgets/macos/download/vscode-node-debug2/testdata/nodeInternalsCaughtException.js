const fs = require('fs');

try {
    fs.readFileSync('sldfk');
} catch (e) {}

console.log('done');