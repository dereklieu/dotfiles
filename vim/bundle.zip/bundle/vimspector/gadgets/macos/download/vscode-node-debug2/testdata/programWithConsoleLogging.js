for (var i = 0; i < 10; i++) {
    console.log('log: ' + i);
    console.error('error: ' + i);
}
