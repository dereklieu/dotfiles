import './file2.mjs';

console.log('file1 loaded');