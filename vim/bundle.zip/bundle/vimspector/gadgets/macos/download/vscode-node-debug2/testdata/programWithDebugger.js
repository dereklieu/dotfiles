var a = [];
a.push("line 1");
a.push("line 2");
a.push("line 3");

debugger;

a.push("line 4");
a.push("line 5");
a.push("line 6");
