require('./symlinkToSrc/file.js');

console.log('hello, world');