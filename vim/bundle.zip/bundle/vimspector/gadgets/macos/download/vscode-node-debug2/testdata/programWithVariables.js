const global = "global"

function locals() {
    let num = 1
    const str = "hello"
    const arr = [num, str]
    const obj = { a: 1, b: "hi" }
    debugger
}

locals()