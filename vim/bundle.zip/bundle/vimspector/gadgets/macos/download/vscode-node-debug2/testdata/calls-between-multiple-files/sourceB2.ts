export function callbackCaller2(cb: Function): void {
    cb();
}
