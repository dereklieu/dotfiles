console.log('hi');
throw new Error('uncaught exception');
